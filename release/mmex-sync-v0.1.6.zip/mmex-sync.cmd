:; exec node app/bundle.js "$@"
@echo off
node app/bundle.js %*
